//
//  Calculator.h
//  Preprocessor
//
//  Created by trainer on 12/18/15.
//  Copyright © 2015 trainer. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Calculator : NSObject
@property NSInteger accumulator;
@end
