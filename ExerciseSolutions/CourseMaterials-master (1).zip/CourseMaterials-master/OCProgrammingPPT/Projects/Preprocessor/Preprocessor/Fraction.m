//
//  Fraction.m
//  Preprocessor
//
//  Created by trainer on 12/18/15.
//  Copyright © 2015 trainer. All rights reserved.
//

#import "Fraction.h"

@implementation Fraction
-(void)setTo:(NSInteger)n over:(NSInteger)d {
    _numerator = n;
    _denominator = d;
}

@end
