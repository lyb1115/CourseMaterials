//
//  AppDelegate.h
//  Preprocessor
//
//  Created by trainer on 12/18/15.
//  Copyright © 2015 trainer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

