var a = 10
var b = 3
10%3
b = -3
10%3

var f1 = 10.1
++f1
