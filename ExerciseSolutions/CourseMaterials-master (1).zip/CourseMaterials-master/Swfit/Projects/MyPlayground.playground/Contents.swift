//: Playground - noun: a place where people can play


var sum = 1
for index in 1...7 {
    sum *= index
}
sum


var sum2 = 0

for index in 1...100 {
    sum2 += index
}
sum2
