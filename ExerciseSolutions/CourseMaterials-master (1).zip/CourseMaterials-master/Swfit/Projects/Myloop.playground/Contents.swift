
var intArr = [1,2,3,4]

for index in intArr {
    print("the idex is :\(index)")
    //continue
    break
    print("not operate")
}


var aInt = 3
switch aInt {
case 1:
    p
    
}